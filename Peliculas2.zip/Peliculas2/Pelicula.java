package Peliculas2;
import java.sql.Date;

public class Pelicula {
			
		//elementos dentro de la clase Pelicula
		private String titulo;
		private Date a�o;
		private String sinopsis;
		private Genero pelicula;
		private String pais;
		
		public String getTitulo() {
			return titulo;
		}
		public void setTitulo(String titulo) {
			this.titulo = titulo;
		}
		public Date getA�o() {
			return a�o;
		}
		public void setA�o(Date a�o) {
			this.a�o = a�o;
		}
		public String getSinopsis() {
			return sinopsis;
		}
		public void setSinopsis(String sinopsis) {
			this.sinopsis = sinopsis;
		}
		public Genero getPelicula() {
			return pelicula;
		}
		public void setPelicula(Genero pelicula) {
			this.pelicula = pelicula;
		}
		public String getPais() {
			return pais;
		}
		public void setPais(String pais) {
			this.pais = pais;
		}
	}	

