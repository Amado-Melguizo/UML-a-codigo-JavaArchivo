package Peliculas2;

public class Director extends Persona{
	//clase director
}
