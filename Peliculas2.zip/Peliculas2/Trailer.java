package Peliculas2;

import java.net.URL;
import java.sql.Time;

public class Trailer {
	//elementos dentro de la clase Trailer
	private URL url;
	private Time duraci�n;
	
	public URL getUrl() {
		return url;
	}
	public void setUrl(URL url) {
		this.url = url;
	}
	public Time getDuraci�n() {
		return duraci�n;
	}
	public void setDuraci�n(Time duraci�n) {
		this.duraci�n = duraci�n;
	}
}
