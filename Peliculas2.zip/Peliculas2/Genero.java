package Peliculas2;


public enum Genero {
	//elementos de la enumeracion Genero
	DRAMA,
	COMEDIA,
	ACCION,
	TERROR,
	ROMANCE,
	AVENTURA,
	SCI_FI;
}
