package Peliculas2;

public class Productor extends Persona{
	//clase productor
}
