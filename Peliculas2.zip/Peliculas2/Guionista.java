package Peliculas2;

public class Guionista extends Persona{
	//clase guionista
}
