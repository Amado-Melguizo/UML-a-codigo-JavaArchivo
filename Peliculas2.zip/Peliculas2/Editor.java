package Peliculas2;

public class Editor extends Persona{
	//clase editor
}
