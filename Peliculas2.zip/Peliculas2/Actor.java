package Peliculas2;

public class Actor extends Persona{
	//clase actor
}
