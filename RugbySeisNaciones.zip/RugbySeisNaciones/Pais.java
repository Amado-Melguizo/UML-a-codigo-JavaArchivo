package RugbySeisNaciones;

public enum Pais{
	//elementos de la enumeracion Pais
	ESCOCIA,
	FRANCIA,
	GALES,
	INGLATERRA,
	IRLANDA,
	ITALIA;
}
