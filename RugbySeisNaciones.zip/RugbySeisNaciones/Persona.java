package RugbySeisNaciones;

import java.sql.Date;

public class Persona{
	//elementos dentro de la clase Persona
	private String nombre;
	private Date fechaNacimiento;
	
}
