package RugbySeisNaciones;

public class Entrenador extends Persona{
	//clase Entrenador
}

