package RugbySeisNaciones;

public class Partido {
	//elementos dentro de la clase Partido
		private int puntosLocal;
		private int puntosVisitante;
		private int bonusLocal;
		private int bonusVisitante;
			
		public void resultado(){
		}
			
		//elementos externos
		public Equipo visitante;
		public Equipo local;
		public Arbitro arbitra;
}