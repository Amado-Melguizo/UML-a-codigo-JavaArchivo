package RugbySeisNaciones;

public class Jugador extends Persona{
	//elementos dentro de la clase Jugador
	private Posicion posicion;
	
	//elementos externos
	public java.util.Collection capit�n = new java.util.TreeSet();
}