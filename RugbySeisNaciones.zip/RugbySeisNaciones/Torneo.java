package RugbySeisNaciones;

import java.sql.Date;

public class Torneo {
	//elementos dentro de la clase Torneo
			private Date a�o;
			public void ganador() {
			}
			
			public void clasificacion() {			
			}
			
			//elementos externos
			public Jornada jornada;
}
