package RugbySeisNaciones;

public class Equipo{
	//elementos dentro de la clase Equipo
	private Pais nombre;
	//elementos externos
	public Jugador jugadores;
	public Entrenador entrena;
}
