package RugbySeisNaciones;

public class Arbitro extends Persona{
	//clase Arbitro
}