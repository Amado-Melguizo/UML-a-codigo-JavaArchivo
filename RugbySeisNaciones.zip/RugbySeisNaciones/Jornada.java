package RugbySeisNaciones;

import java.sql.Date;

public class Jornada {
	//elementos dentro de la clase Jornada
	private Date fecha;
	//elementos externos
	public Partido partido;
}
