package RugbySeisNaciones;

public enum Posicion{
	//elementos de la enumeracion Posicion
	PILIER,
	TALONADOR,
	SEGUNDA_LINEA,
	TERCERA_LINEA,
	MEDIO_MELE,
	APERTURA,
	CENTRO,
	ALA,
	ZAGUERO;
}