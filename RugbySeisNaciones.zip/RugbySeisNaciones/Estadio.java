package RugbySeisNaciones;

public class Estadio {
	//elementos dentro de la clase Estadio
	private String nombre;
	private int capacidad;
	private String ciudad;
}
