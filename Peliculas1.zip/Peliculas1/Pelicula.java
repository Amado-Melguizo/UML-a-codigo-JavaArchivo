package Peliculas1;
import java.sql.Date;
import Peliculas1.Genero;

public class Pelicula {
			
		//elementos dentro de la clase Pelicula
		private String titulo;
		private Date a�o;
		private String sinopsis;
		private Genero pelicula;
		private String pais;
		
		//elementos externos
		public java.util.Collection<?> actor = new java.util.TreeSet<Object>();
		public java.util.Collection<?> director = new java.util.TreeSet<Object>();
		public java.util.Collection<?> productor = new java.util.TreeSet<Object>();
		public java.util.Collection<?> guionista = new java.util.TreeSet<Object>();
		
		public String getTitulo() {
			return titulo;
		}
		public void setTitulo(String titulo) {
			this.titulo = titulo;
		}
		public Date getA�o() {
			return a�o;
		}
		public void setA�o(Date a�o) {
			this.a�o = a�o;
		}
		public String getSinopsis() {
			return sinopsis;
		}
		public void setSinopsis(String sinopsis) {
			this.sinopsis = sinopsis;
		}
		public Genero getPelicula() {
			return pelicula;
		}
		public void setPelicula(Genero pelicula) {
			this.pelicula = pelicula;
		}
		public String getPais() {
			return pais;
		}
		public void setPais(String pais) {
			this.pais = pais;
		}
		public java.util.Collection<?> getActor() {
			return actor;
		}
		public void setActor(java.util.Collection<?> actor) {
			this.actor = actor;
		}
		public java.util.Collection<?> getDirector() {
			return director;
		}
		public void setDirector(java.util.Collection<?> director) {
			this.director = director;
		}
		public java.util.Collection<?> getProductor() {
			return productor;
		}
		public void setProductor(java.util.Collection<?> productor) {
			this.productor = productor;
		}
		public java.util.Collection<?> getGuionista() {
			return guionista;
		}
		public void setGuionista(java.util.Collection<?> guionista) {
			this.guionista = guionista;
		}
	}	

